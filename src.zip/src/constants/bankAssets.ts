
import meliBank from '/src/assets/images/banks/melli bank.png';
import sepahBank from '/src/assets/images/banks/sepah bank.png';
import sanatOmadan from '/src/assets/images/banks/sanAt o madan bank.png';
import keshavarzi from '/src/assets/images/banks/keshavarzi bank.png';
import maskan from '/src/assets/images/banks/maskan bank.png';
import sinaBank from '/src/assets/images/banks/sina bank.png';
import postBank from '/src/assets/images/banks/post-bank.png';
import samanBank from '/src/assets/images/banks/saman bank.png';
import tosehTavon from '/src/assets/images/banks/toseE taAvon bank.png';
import eghtesadNovin from '/src/assets/images/banks/eghtesad novin bank.png';
import parsianBank from '/src/assets/images/banks/parsian bank.png';
import pasargadBank from '/src/assets/images/banks/pasargad bank.png';
import karafarinBank from '/src/assets/images/banks/kar afarin bank.png';
import sarmayehBank from '/src/assets/images/banks/sarmaye bank.png';
import shahrBank from '/src/assets/images/banks/shahr-bank.png';
import deyBank from '/src/assets/images/banks/dey bank.png';
import saderatBank from '/src/assets/images/banks/saderat.png';
import melatBank from '/src/assets/images/banks/mellat bank.png';
import tejaratBank from '/src/assets/images/banks/tejarat bank.png';
import refahBank from '/src/assets/images/banks/refah bank.png';
import ansarBank from '/src/assets/images/banks/ansar bank.png';
import mehreEghtesad from '/src/assets/images/banks/mehre eghtesad.png';
import ghavaminBank from '/src/assets/images/banks/ghavamin.png';
import resalatBank from '/src/assets/images/banks/resalat.png';
import ayandehBank from '/src/assets/images/banks/ayandeh bank.png';
import tosehSaderatBank from '/src/assets/images/banks/toseE saderat bank.png';
import toseEetebari  from '/src/assets/images/banks/toseE etebari.png';
import gardeshgary from '/src/assets/images/banks/gardeshgari.png';
import mehreirangharzolhasanebank from '/src/assets/images/banks/mehre iran gharzolhasane bank.png';
import iranzaminBank from '/src/assets/images/banks/iranzamin-bank.png';

export {
  meliBank,
  sepahBank,
  sanatOmadan,
  keshavarzi,
  maskan,
  sinaBank,
  postBank,
  samanBank,
  tosehTavon,
  eghtesadNovin,
  parsianBank,
  pasargadBank,
  karafarinBank,
  sarmayehBank,
  shahrBank,
  deyBank,
  saderatBank,
  melatBank,
  tejaratBank,
  refahBank,
  ansarBank,
  mehreEghtesad,
  ghavaminBank,
  resalatBank,
  ayandehBank,
  tosehSaderatBank,
  toseEetebari,
  gardeshgary,
  mehreirangharzolhasanebank,
  iranzaminBank,
};