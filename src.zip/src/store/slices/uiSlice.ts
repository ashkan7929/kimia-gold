import { createSlice } from '@reduxjs/toolkit';
import type { PayloadAction } from '@reduxjs/toolkit';

export interface Notification {
	id: string;
	type: 'success' | 'error' | 'warning' | 'info';
	title: string;
	message: string;
	duration?: number;
	timestamp: number;
}

interface UIState {
	theme: 'light' | 'dark';
	sidebarOpen: boolean;
	notifications: Notification[];
	modals: {
		loginModal: boolean;
		registerModal: boolean;
		buyModal: boolean;
		sellModal: boolean;
		profileModal: boolean;
	};
	loading: {
		global: boolean;
		auth: boolean;
		portfolio: boolean;
		market: boolean;
	};
}

const initialState: UIState = {
	theme: (localStorage.getItem('theme') as 'light' | 'dark') || 'light',
	sidebarOpen: false,
	notifications: [],
	modals: {
		loginModal: false,
		registerModal: false,
		buyModal: false,
		sellModal: false,
		profileModal: false,
	},
	loading: {
		global: false,
		auth: false,
		portfolio: false,
		market: false,
	},
};

const uiSlice = createSlice({
	name: 'ui',
	initialState,
	reducers: {
		setTheme: (state, action: PayloadAction<'light' | 'dark'>) => {
			state.theme = action.payload;
			localStorage.setItem('theme', action.payload);
		},
		toggleTheme: (state) => {
			state.theme = state.theme === 'light' ? 'dark' : 'light';
			localStorage.setItem('theme', state.theme);
		},
		setSidebarOpen: (state, action: PayloadAction<boolean>) => {
			state.sidebarOpen = action.payload;
		},
		toggleSidebar: (state) => {
			state.sidebarOpen = !state.sidebarOpen;
		},
		addNotification: (state, action: PayloadAction<Omit<Notification, 'id' | 'timestamp'>>) => {
			const notification: Notification = {
				...action.payload,
				id: Date.now().toString(),
				timestamp: Date.now(),
			};
			state.notifications.push(notification);
		},
		removeNotification: (state, action: PayloadAction<string>) => {
			state.notifications = state.notifications.filter(n => n.id !== action.payload);
		},
		clearNotifications: (state) => {
			state.notifications = [];
		},
		openModal: (state, action: PayloadAction<keyof UIState['modals']>) => {
			state.modals[action.payload] = true;
		},
		closeModal: (state, action: PayloadAction<keyof UIState['modals']>) => {
			state.modals[action.payload] = false;
		},
		closeAllModals: (state) => {
			Object.keys(state.modals).forEach(key => {
				state.modals[key as keyof UIState['modals']] = false;
			});
		},
		setLoading: (state, action: PayloadAction<{ key: keyof UIState['loading']; value: boolean }>) => {
			state.loading[action.payload.key] = action.payload.value;
		},
		setGlobalLoading: (state, action: PayloadAction<boolean>) => {
			state.loading.global = action.payload;
		},
	},
});

export const {
	setTheme,
	toggleTheme,
	setSidebarOpen,
	toggleSidebar,
	addNotification,
	removeNotification,
	clearNotifications,
	openModal,
	closeModal,
	closeAllModals,
	setLoading,
	setGlobalLoading,
} = uiSlice.actions;

export default uiSlice.reducer;