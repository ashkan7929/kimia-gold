/* src/pages/Auth/index.ts */
export { default as MobilePage } from './MobilePage';
// export { default as ChooseMethodPage } from './ChooseMethodPage';
export { default as OtpPage } from './OtpPage';
export { default as AuthPage } from './AuthPage';
